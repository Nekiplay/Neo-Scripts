package net.azureaaron.hmapi.mixins;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;

import net.azureaaron.hmapi.network.WrappedPacketCodec;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2817;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

@Mixin(value = class_2817.class, priority = 1888)
public class CustomPayloadC2SPacketMixin {

	@ModifyExpressionValue(method = "<clinit>", at = @At(value = "INVOKE", target = "Lnet/minecraft/network/packet/CustomPayload;createCodec(Lnet/minecraft/network/packet/CustomPayload$CodecFactory;Ljava/util/List;)Lnet/minecraft/network/codec/PacketCodec;"))
	private static class_9139<class_2540, class_8710> wrapC2SPacketCodec(class_9139<class_2540, class_8710> original) {
		return new WrappedPacketCodec(original, class_2598.field_11941);
	}
}
