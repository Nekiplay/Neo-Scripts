package net.azureaaron.hmapi.mixins;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;

import net.azureaaron.hmapi.network.HijackedCustomPayload;
import net.azureaaron.hmapi.network.WrappedPacketCodec;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_2658;
import net.minecraft.class_8705;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

@Mixin(value = class_2658.class, priority = 1888)
public abstract class CustomPayloadS2CPacketMixin {
	@Shadow
	public abstract class_8710 payload();

	@ModifyExpressionValue(method = "<clinit>", at = @At(value = "INVOKE", target = "Lnet/minecraft/network/packet/CustomPayload;createCodec(Lnet/minecraft/network/packet/CustomPayload$CodecFactory;Ljava/util/List;)Lnet/minecraft/network/codec/PacketCodec;"))
	private static class_9139<class_2540, class_8710> wrapS2CPacketCodec(class_9139<class_2540, class_8710> original) {
		return new WrappedPacketCodec(original, class_2598.field_11942);
	}

	@Inject(method = "apply", at = @At("HEAD"), cancellable = true)
	private void onApplication(class_8705 clientCommonPacketListener, CallbackInfo ci) {
		if (payload() instanceof HijackedCustomPayload hijacked) {
			new class_2658(hijacked.original()).method_53024(clientCommonPacketListener);
			new class_2658(hijacked.hijacked()).method_53024(clientCommonPacketListener);

			ci.cancel();
		}
	}
}
