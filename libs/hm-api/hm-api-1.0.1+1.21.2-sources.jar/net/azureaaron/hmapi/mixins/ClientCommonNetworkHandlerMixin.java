package net.azureaaron.hmapi.mixins;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import net.azureaaron.hmapi.network.HypixelNetworkingImpl;
import net.azureaaron.hmapi.network.packet.s2c.HypixelS2CPacket;
import net.minecraft.class_2658;
import net.minecraft.class_8673;

@Mixin(value = class_8673.class, priority = 888)
public class ClientCommonNetworkHandlerMixin {

	@Inject(method = "onCustomPayload(Lnet/minecraft/network/packet/s2c/common/CustomPayloadS2CPacket;)V", at = @At("HEAD"), cancellable = true)
	private void onCustomPayloadReceived(class_2658 customPayload, CallbackInfo ci) {
		if (customPayload.comp_1646() instanceof HypixelS2CPacket packet) {
			HypixelNetworkingImpl.handlePayload(packet);
			ci.cancel();
		}
	}
}
