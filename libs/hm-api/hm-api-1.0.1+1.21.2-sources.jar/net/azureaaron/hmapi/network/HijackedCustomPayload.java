package net.azureaaron.hmapi.network;

import net.minecraft.class_2960;
import net.minecraft.class_8710;
import org.jetbrains.annotations.ApiStatus;

@ApiStatus.Internal
public record HijackedCustomPayload(class_8710 original, class_8710 hijacked) implements class_8710 {
	private static final class_8710.class_9154<HijackedCustomPayload> ID = new class_8710.class_9154<HijackedCustomPayload>(class_2960.method_60655("hmapi", "hijacked"));

	@Override
	public class_9154<? extends class_8710> method_56479() {
		return ID;
	}
}
