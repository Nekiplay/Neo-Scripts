package net.azureaaron.hmapi.network.packet.v2.s2c;

import java.util.Collections;
import java.util.Map;
import java.util.UUID;

import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.Unmodifiable;

import it.unimi.dsi.fastutil.objects.Object2ReferenceOpenHashMap;
import net.azureaaron.hmapi.data.party.PartyRole;
import net.azureaaron.hmapi.network.packet.s2c.HypixelS2CPacket;
import net.azureaaron.hmapi.utils.PacketCodecUtils;
import net.minecraft.class_2960;
import net.minecraft.class_4844;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * This packet gives information about whether the player is in a party, and if they are the {@link #members} map is populated with each party member and their role.
 * 
 * @param inParty whether the player is in a party or not
 * @param members a mapping of player {@link UUID}s to {@link PartyRole}s, this field will not be null when {@link #inParty} returns true
 */
public record PartyInfoS2CPacket(boolean inParty, @Nullable @Unmodifiable Map<UUID, PartyRole> members) implements HypixelS2CPacket {
	public static final class_8710.class_9154<HypixelS2CPacket> ID = new class_8710.class_9154<>(class_2960.method_60655("hypixel", "party_info"));
	private static final class_9139<class_9129, PartyInfoS2CPacket> IN_PARTY_PACKET_CODEC = class_9139.method_56434(class_9135.method_56377(Object2ReferenceOpenHashMap::new, class_4844.field_48453, class_9135.method_56375(i -> PartyRole.values()[i], PartyRole::ordinal)), PartyInfoS2CPacket::members, PartyInfoS2CPacket::new);
	public static final class_9139<class_9129, PartyInfoS2CPacket> PACKET_CODEC = PacketCodecUtils.dispatchConditionally(IN_PARTY_PACKET_CODEC, class_9139.method_56431(new PartyInfoS2CPacket(false, null)));

	private PartyInfoS2CPacket(Map<UUID, PartyRole> members) {
		this(true, Collections.unmodifiableMap(members));
	}

	@Override
	public class_9154<HypixelS2CPacket> method_56479() {
		return ID;
	}
}
