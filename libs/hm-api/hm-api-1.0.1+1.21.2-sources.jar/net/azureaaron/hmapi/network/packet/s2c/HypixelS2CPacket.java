package net.azureaaron.hmapi.network.packet.s2c;

import org.jetbrains.annotations.ApiStatus;

import net.azureaaron.hmapi.network.packet.HypixelPacket;
import net.minecraft.class_2960;
import net.minecraft.class_8710;

/**
 * Used to establish a basic record-compatible inheritance model for each S2C packet. In order to get the original type you
 * must use pattern matching or {@code instanceof}.
 */
@ApiStatus.NonExtendable
public interface HypixelS2CPacket extends HypixelPacket {
	/**
	 * Catch all instance for unknown S2C packets, event handlers will never receive this.
	 */
	@ApiStatus.Internal
	HypixelS2CPacket NOP = new HypixelS2CPacket() {

		@Override
		public class_9154<? extends class_8710> method_56479() {
			//This needs to return something non null that is a packet channel we're registered to
			return new class_8710.class_9154<class_8710>(class_2960.method_60655("hypixel", "location"));
		}
	};
}
