package net.azureaaron.hmapi.network.packet.v1.s2c;

import java.util.Optional;

import net.azureaaron.hmapi.data.rank.MonthlyPackageRank;
import net.azureaaron.hmapi.data.rank.PackageRank;
import net.azureaaron.hmapi.data.rank.PlayerRank;
import net.azureaaron.hmapi.network.packet.s2c.HypixelS2CPacket;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * This packet gives information about the player's rank and how its displayed.
 * 
 * @param playerRank         the player's base rank type
 * @param packageRank        the player's paid rank (if applicable) (e.g. MVP++)
 * @param monthlyPackageRank the player's monthly subscription rank, currently only MVP++ applies to this
 * @param prefix             the player's rank prefix override (Note: this may contain formatting codes)
 */
public record PlayerInfoS2CPacket(PlayerRank playerRank, PackageRank packageRank, MonthlyPackageRank monthlyPackageRank, Optional<String> prefix) implements HypixelS2CPacket {
	public static final class_8710.class_9154<HypixelS2CPacket> ID = new class_8710.class_9154<>(class_2960.method_60655("hypixel", "player_info"));
	public static final class_9139<class_9129, PlayerInfoS2CPacket> PACKET_CODEC = class_9139.method_56905(class_9135.method_56375(PlayerRank.BY_ID, PlayerRank::id), PlayerInfoS2CPacket::playerRank,
			class_9135.method_56375(PackageRank.BY_ID, PackageRank::id), PlayerInfoS2CPacket::packageRank,
			class_9135.method_56375(MonthlyPackageRank.BY_ID, MonthlyPackageRank::id), PlayerInfoS2CPacket::monthlyPackageRank,
			class_9135.method_56382(class_9135.field_48554), PlayerInfoS2CPacket::prefix,
			PlayerInfoS2CPacket::new);

	@Override
	public class_9154<? extends class_8710> method_56479() {
		return ID;
	}
}
