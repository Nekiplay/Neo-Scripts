package net.azureaaron.hmapi.network.packet;

import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;
import org.jetbrains.annotations.ApiStatus;

@ApiStatus.Internal
public interface HypixelPacket extends class_8710 {

	@ApiStatus.Internal
	public record Unknown(class_2960 id) implements HypixelPacket {

		public static class_9139<class_2540, Unknown> createPacketCodec(class_2960 id) {
			return new class_9139<>() {

				@Override
				public Unknown decode(class_2540 buf) {
					//Since we duplicate the buffer we don't need to read all bytes
					return new Unknown(id);
				}

				@Override
				public void encode(class_2540 buf, Unknown value) {
					//We will never encode this
				}
			};
		}

		@Override
		public class_9154<Unknown> method_56479() {
			return new class_8710.class_9154<>(this.id);
		}
	}
}
