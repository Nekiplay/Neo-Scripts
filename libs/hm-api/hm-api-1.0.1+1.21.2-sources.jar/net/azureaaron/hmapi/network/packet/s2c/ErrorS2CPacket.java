package net.azureaaron.hmapi.network.packet.s2c;

import java.util.function.Function;

import net.azureaaron.hmapi.data.error.ErrorReason;
import net.azureaaron.hmapi.data.error.ModApiErrorReason;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * This packet is used to communicate when Hypixel returned an error instead of a successful packet.
 * 
 * @param id the id of the packet for which this error was created for
 * @param reason the reason behind the error
 * 
 * @see {@link ModApiErrorReason}
 * @see {@link net.azureaaron.hmapi.data.error.InternalErrorReason InternalErrorReason}
 */
public record ErrorS2CPacket(class_8710.class_9154<HypixelS2CPacket> id, ErrorReason reason) implements HypixelS2CPacket {
	public static final Function<class_8710.class_9154<HypixelS2CPacket>, class_9139<class_9129, ErrorS2CPacket>> PACKET_CODEC = payloadId -> class_9139.method_56434(class_9135.method_56375(ModApiErrorReason::tryResolveReason, ErrorReason::id), ErrorS2CPacket::reason,
			errorId -> new ErrorS2CPacket(payloadId, errorId));

	@Override
	public class_9154<? extends class_8710> method_56479() {
		return this.id;
	}
}
