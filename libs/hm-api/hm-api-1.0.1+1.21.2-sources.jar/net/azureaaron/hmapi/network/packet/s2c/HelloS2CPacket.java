package net.azureaaron.hmapi.network.packet.s2c;

import net.azureaaron.hmapi.data.server.Environment;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * This packet is sent each time upon logging into Hypixel, currently it only communicates the server's environment.
 * 
 * @param environment The current Hypixel server environment
 * 
 * @see {@link Environment}
 * @implSpec This record/packet is subject to potentially breaking changes in the future without notice as specified by Hypixel.
 */
public record HelloS2CPacket(Environment environment) implements HypixelS2CPacket {
	public static final class_8710.class_9154<HypixelS2CPacket> ID = new class_8710.class_9154<>(class_2960.method_60655("hypixel", "hello"));
	public static final class_9139<class_9129, HelloS2CPacket> PACKET_CODEC = class_9139.method_56434(class_9135.method_56375(i -> Environment.values()[i], Environment::ordinal), HelloS2CPacket::environment, HelloS2CPacket::new);

	@Override
	public class_9154<? extends class_8710> method_56479() {
		return ID;
	}
}
