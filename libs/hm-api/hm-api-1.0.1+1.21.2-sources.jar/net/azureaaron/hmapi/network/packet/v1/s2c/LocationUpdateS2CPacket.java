package net.azureaaron.hmapi.network.packet.v1.s2c;

import java.util.Optional;

import net.azureaaron.hmapi.network.packet.s2c.HypixelS2CPacket;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * When subscribed to this event packet it's sent every time the player swaps servers and it gives information on their new location on Hypixel.
 * 
 * @param serverName the name of the server (e.g. {@code mini88A})
 * @param serverType the type of server the player has connected to if available such as {@code SKYBLOCK}
 * @param lobbyName  the current lobby's name, this value is only present when the player is in a lobby (e.g. {@code prototypelobby2})
 * @param mode       the current gamemode's name if present such as {@code dynamic} for SkyBlock Private Islands
 * @param map        the current server's map if available (e.g. {@code Dungeon} for SkyBlock Dungeons)
 * 
 * @see <a href="https://github.com/HypixelDev/HypixelData/tree/master/src/main/java/net/hypixel/data/type">Hypixel Data</a> ServerType varient enum constant names for possible {@link #serverType} values.
 */
public record LocationUpdateS2CPacket(String serverName, Optional<String> serverType, Optional<String> lobbyName, Optional<String> mode, Optional<String> map) implements HypixelS2CPacket {
	public static final class_8710.class_9154<HypixelS2CPacket> ID = new class_8710.class_9154<>(class_2960.method_60655("hyevent", "location"));
	public static final class_9139<class_9129, LocationUpdateS2CPacket> PACKET_CODEC = class_9139.method_56906(class_9135.field_48554, LocationUpdateS2CPacket::serverName,
			class_9135.method_56382(class_9135.field_48554), LocationUpdateS2CPacket::serverType,
			class_9135.method_56382(class_9135.field_48554), LocationUpdateS2CPacket::lobbyName,
			class_9135.method_56382(class_9135.field_48554), LocationUpdateS2CPacket::mode,
			class_9135.method_56382(class_9135.field_48554), LocationUpdateS2CPacket::map, LocationUpdateS2CPacket::new);

	@Override
	public class_9154<? extends class_8710> method_56479() {
		return ID;
	}
}
