package net.azureaaron.hmapi.network.packet.c2s;

import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record RegisterC2SPacket(int version, Object2IntMap<class_2960> eventsToRegister) implements HypixelC2SPacket {
	public static final class_8710.class_9154<RegisterC2SPacket> ID = new class_8710.class_9154<>(class_2960.method_60655("hypixel", "register"));
	public static final class_9139<class_9129, RegisterC2SPacket> PACKET_CODEC = class_9139.method_56435(class_9135.field_48550, RegisterC2SPacket::version,
			class_9135.method_57992(Object2IntOpenHashMap::new, class_2960.field_48267, class_9135.field_48550, 5), RegisterC2SPacket::eventsToRegister, RegisterC2SPacket::new);

	@Override
	public class_9154<? extends class_8710> method_56479() {
		return ID;
	}
}
