package net.azureaaron.hmapi.network.packet.c2s;

import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record PlayerInfoC2SPacket(int version) implements HypixelC2SPacket {
	public static final class_8710.class_9154<PlayerInfoC2SPacket> ID = new class_8710.class_9154<>(class_2960.method_60655("hypixel", "player_info"));
	public static final class_9139<class_9129, PlayerInfoC2SPacket> PACKET_CODEC = class_9139.method_56434(class_9135.field_48550, PlayerInfoC2SPacket::version, PlayerInfoC2SPacket::new);

	@Override
	public class_9154<? extends class_8710> method_56479() {
		return ID;
	}
}
