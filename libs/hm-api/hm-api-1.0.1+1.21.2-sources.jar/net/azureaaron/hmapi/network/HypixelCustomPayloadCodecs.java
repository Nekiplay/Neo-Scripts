package net.azureaaron.hmapi.network;

import org.jetbrains.annotations.ApiStatus;

import com.google.common.collect.Lists;

import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import net.azureaaron.hmapi.network.packet.HypixelPacket;
import net.azureaaron.hmapi.network.packet.c2s.PartyInfoC2SPacket;
import net.azureaaron.hmapi.network.packet.c2s.PlayerInfoC2SPacket;
import net.azureaaron.hmapi.network.packet.c2s.RegisterC2SPacket;
import net.azureaaron.hmapi.network.packet.s2c.ErrorS2CPacket;
import net.azureaaron.hmapi.network.packet.s2c.HelloS2CPacket;
import net.azureaaron.hmapi.network.packet.v1.s2c.LocationUpdateS2CPacket;
import net.azureaaron.hmapi.network.packet.v1.s2c.PlayerInfoS2CPacket;
import net.azureaaron.hmapi.network.packet.v2.s2c.PartyInfoS2CPacket;
import net.azureaaron.hmapi.utils.PacketCodecUtils;
import net.minecraft.class_156;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

@ApiStatus.Internal
public class HypixelCustomPayloadCodecs {
	private static final class_9139<class_2540, class_8710> C2S_PACKET_CODEC = class_8710.method_56485(
			HypixelPacket.Unknown::createPacketCodec, Lists.newArrayList(
					createType(PartyInfoC2SPacket.ID, PartyInfoC2SPacket.PACKET_CODEC),
					createType(PlayerInfoC2SPacket.ID, PlayerInfoC2SPacket.PACKET_CODEC),
					createType(RegisterC2SPacket.ID, RegisterC2SPacket.PACKET_CODEC))
			);

	private static final class_9139<class_2540, class_8710> S2C_PACKET_CODEC = class_8710.method_56485(
			HypixelPacket.Unknown::createPacketCodec, Lists.newArrayList(
					createType(PartyInfoS2CPacket.ID, PacketCodecUtils.dispatchHypixel(
							class_156.method_654(new Int2ObjectOpenHashMap<>(), map -> {
								map.put(2, PartyInfoS2CPacket.PACKET_CODEC);
							}),
							ErrorS2CPacket.PACKET_CODEC.apply(PartyInfoS2CPacket.ID))),
					createType(PlayerInfoS2CPacket.ID, PacketCodecUtils.dispatchHypixel(
							class_156.method_654(new Int2ObjectOpenHashMap<>(), map -> map.put(1, PlayerInfoS2CPacket.PACKET_CODEC)),
							ErrorS2CPacket.PACKET_CODEC.apply(PlayerInfoS2CPacket.ID))),
					createType(HelloS2CPacket.ID, PacketCodecUtils.dispatchSafely(HelloS2CPacket.PACKET_CODEC, ErrorS2CPacket.PACKET_CODEC.apply(HelloS2CPacket.ID))),
					createType(LocationUpdateS2CPacket.ID, PacketCodecUtils.dispatchHypixel(
							class_156.method_654(new Int2ObjectOpenHashMap<>(), map -> map.put(1, LocationUpdateS2CPacket.PACKET_CODEC)),
							ErrorS2CPacket.PACKET_CODEC.apply(LocationUpdateS2CPacket.ID))))
			);

	@SuppressWarnings("unchecked")
	private static <B extends class_2540, T extends class_8710> class_8710.class_9155<class_2540, class_8710> createType(class_8710.class_9154<T> id, class_9139<B, T> packetCodec) {
		return new class_8710.class_9155<>(id, class_9139.class.cast(packetCodec));
	}

	static class_9139<class_2540, class_8710> get4Direction(class_2598 direction) {
		return switch (direction) {
			case field_11941 -> C2S_PACKET_CODEC;
			case field_11942 -> S2C_PACKET_CODEC;
		};
	}
}
