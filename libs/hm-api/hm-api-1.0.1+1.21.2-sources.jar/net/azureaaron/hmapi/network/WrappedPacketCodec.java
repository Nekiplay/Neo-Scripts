package net.azureaaron.hmapi.network;

import org.jetbrains.annotations.ApiStatus;

import net.azureaaron.hmapi.network.packet.HypixelPacket;
import net.azureaaron.hmapi.network.packet.c2s.HypixelC2SPacket;
import net.minecraft.class_2540;
import net.minecraft.class_2598;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

@ApiStatus.Internal
public record WrappedPacketCodec(class_9139<class_2540, class_8710> wrappedPacketCodec, class_2598 direction) implements class_9139<class_2540, class_8710> {

	@Override
	public class_8710 decode(class_2540 buf) {
		class_2540 copiedBuf = new class_2540(buf.slice());

		class_8710 original = this.wrappedPacketCodec.decode(buf);
		class_8710 hijacked = HypixelCustomPayloadCodecs.get4Direction(this.direction).decode(copiedBuf);

		return hijacked instanceof HypixelPacket.Unknown ? original : new HijackedCustomPayload(original, hijacked);
	}

	@Override
	public void encode(class_2540 buf, class_8710 payload) {
		if (payload instanceof HypixelC2SPacket) {
			HypixelCustomPayloadCodecs.get4Direction(this.direction).encode(buf, payload);
		} else {
			this.wrappedPacketCodec.encode(buf, payload);
		}
	}
}
