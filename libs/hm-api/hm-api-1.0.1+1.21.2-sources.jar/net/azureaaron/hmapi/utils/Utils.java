package net.azureaaron.hmapi.utils;

import net.minecraft.class_310;
import org.jetbrains.annotations.ApiStatus;

@ApiStatus.Internal
public class Utils {
	/**
	 * Available solely for debugging purposes.
	 */
	private static final String HYPIXEL_ADDRESS_OVERRIDE = System.getProperty("hmapi.alternateHypixelAddress", "");

	public static boolean isOnHypixel() {
		class_310 client = class_310.method_1551();
		String serverAddress = client.method_1558() != null ? client.method_1558().field_3761.toLowerCase() : "";
		String serverBrand = client.field_1724 != null && client.field_1724.field_3944 != null && client.field_1724.field_3944.method_52790() != null ? client.field_1724.field_3944.method_52790() : "";

		return (!serverAddress.isEmpty() && HYPIXEL_ADDRESS_OVERRIDE.equalsIgnoreCase(serverAddress)) || serverAddress.contains("hypixel.net") || serverAddress.contains("hypixel.io") || serverBrand.contains("Hypixel BungeeCord");
	}

	public static int requireInRange(int version, int min, int max) {
		if (!(version >= min && version <= max)) {
			throw new UnsupportedOperationException("Requested an unsupported packet version");
		}

		return version;
	}

	public static void requireIsOnHypixel() {
		if (!isOnHypixel()) throw new UnsupportedOperationException("Requested to send a C2S packet to Hypixel whilst not being on the server!");
	}
}
